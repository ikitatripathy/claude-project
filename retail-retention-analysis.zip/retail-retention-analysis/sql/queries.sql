-- Run against data/processed/retail.db (SQLite). Each block is executed by run_analysis.py
-- and exported to outputs/tables/sql_<name>.csv

-- name: top_cities_by_revenue
SELECT c.city,
       COUNT(DISTINCT o.customer_id)            AS customers,
       COUNT(o.order_id)                        AS orders,
       ROUND(SUM(o.revenue), 0)                 AS revenue,
       ROUND(SUM(o.revenue) * 100.0 / SUM(SUM(o.revenue)) OVER (), 1) AS revenue_share_pct,
       RANK() OVER (ORDER BY SUM(o.revenue) DESC) AS revenue_rank
FROM orders o JOIN customers c USING (customer_id)
WHERE o.status = 'Delivered'
GROUP BY c.city
ORDER BY revenue DESC;

-- name: customer_repeat_gap_days
-- Days between consecutive orders per customer using LAG(), summarised
WITH seq AS (
  SELECT customer_id, order_date,
         JULIANDAY(order_date) - JULIANDAY(LAG(order_date) OVER (PARTITION BY customer_id ORDER BY order_date)) AS gap
  FROM orders WHERE status = 'Delivered'
)
SELECT ROUND(AVG(gap), 1) AS avg_gap_days, MIN(gap) AS min_gap, MAX(gap) AS max_gap, COUNT(gap) AS n_gaps
FROM seq WHERE gap IS NOT NULL;

-- name: running_revenue_and_mom
WITH monthly AS (
  SELECT month, ROUND(SUM(revenue), 0) AS revenue FROM orders WHERE status = 'Delivered' GROUP BY month
)
SELECT month, revenue,
       SUM(revenue) OVER (ORDER BY month)                                   AS cumulative_revenue,
       ROUND((revenue - LAG(revenue) OVER (ORDER BY month)) * 100.0
             / LAG(revenue) OVER (ORDER BY month), 1)                       AS mom_growth_pct
FROM monthly ORDER BY month;

-- name: payment_method_return_rates
SELECT payment_method,
       COUNT(*)                                                        AS orders,
       ROUND(100.0 * SUM(status = 'Returned')  / COUNT(*), 2)          AS return_rate_pct,
       ROUND(100.0 * SUM(status = 'Cancelled') / COUNT(*), 2)          AS cancel_rate_pct
FROM orders GROUP BY payment_method ORDER BY return_rate_pct DESC;

-- name: top_product_pairs_bought_together
SELECT p1.product_name AS product_a, p2.product_name AS product_b, COUNT(*) AS times_together
FROM order_items a
JOIN order_items b ON a.order_id = b.order_id AND a.product_id < b.product_id
JOIN products p1 ON p1.product_id = a.product_id
JOIN products p2 ON p2.product_id = b.product_id
GROUP BY a.product_id, b.product_id
ORDER BY times_together DESC LIMIT 10;

-- name: first_order_category_vs_repeat
-- Does the category of a customer's FIRST order affect whether they come back?
WITH ranked AS (
  SELECT o.customer_id, o.order_id,
         ROW_NUMBER() OVER (PARTITION BY o.customer_id ORDER BY o.order_date, o.order_id) AS rn
  FROM orders o WHERE o.status = 'Delivered'
),
first_cat AS (
  SELECT r.customer_id, p.category, SUM(i.quantity * p.unit_price) AS val,
         ROW_NUMBER() OVER (PARTITION BY r.customer_id ORDER BY SUM(i.quantity * p.unit_price) DESC) AS k
  FROM ranked r JOIN order_items i ON i.order_id = r.order_id JOIN products p ON p.product_id = i.product_id
  WHERE r.rn = 1 GROUP BY r.customer_id, p.category
),
n AS (SELECT customer_id, COUNT(*) AS n_orders FROM orders WHERE status = 'Delivered' GROUP BY customer_id)
SELECT f.category, COUNT(*) AS customers,
       ROUND(100.0 * AVG(n.n_orders >= 2), 1) AS repeat_rate_pct
FROM first_cat f JOIN n USING (customer_id) WHERE f.k = 1
GROUP BY f.category ORDER BY repeat_rate_pct DESC;
