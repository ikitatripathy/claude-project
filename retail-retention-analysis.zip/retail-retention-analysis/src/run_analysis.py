"""End-to-end pipeline: clean -> SQL (SQLite) -> analysis -> charts + findings.
Run:  python src/generate_data.py && python src/run_analysis.py"""
import json, sqlite3
from pathlib import Path
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt, seaborn as sns
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
RAW, PROC, CH, TB = ROOT/"data/raw", ROOT/"data/processed", ROOT/"outputs/charts", ROOT/"outputs/tables"
for p in (PROC, CH, TB): p.mkdir(parents=True, exist_ok=True)
sns.set_theme(style="whitegrid", context="talk", palette="deep")
plt.rcParams.update({"figure.dpi": 110, "axes.titleweight": "bold", "axes.titlesize": 15})
fmt_inr = lambda x: f"₹{x/1e5:,.1f}L" if x < 1e7 else f"₹{x/1e7:,.2f}Cr"
log = {}   # data-quality + key metrics, written to JSON for the README

# ============ 1. CLEANING ============
cust = pd.read_csv(RAW/"customers.csv"); prod = pd.read_csv(RAW/"products.csv")
orders = pd.read_csv(RAW/"orders.csv"); items = pd.read_csv(RAW/"order_items.csv")

log["dq"] = {}
n0 = len(orders); orders = orders.drop_duplicates(); log["dq"]["duplicate_orders_removed"] = n0 - len(orders)
orders["order_date"] = pd.to_datetime(orders["order_date"], errors="coerce")
log["dq"]["invalid_dates_removed"] = int(orders["order_date"].isna().sum())
orders = orders.dropna(subset=["order_date"])
log["dq"]["missing_payment_method_filled"] = int(orders["payment_method"].isna().sum())
orders["payment_method"] = orders["payment_method"].fillna("Unknown")

cust["city"] = cust["city"].str.strip().str.title()
log["dq"]["missing_channel_filled"] = int(cust["acquisition_channel"].isna().sum())
cust["acquisition_channel"] = cust["acquisition_channel"].fillna("Unknown")
bad_age = (cust["age"] < 18) | (cust["age"] > 80)
log["dq"]["impossible_or_missing_age"] = int(bad_age.sum() + cust["age"].isna().sum() - (bad_age & cust["age"].isna()).sum())
cust.loc[bad_age, "age"] = np.nan
cust["age"] = cust["age"].fillna(cust["age"].median())          # median imputation
cust["signup_date"] = pd.to_datetime(cust["signup_date"])

line = items.merge(prod, on="product_id")
line["gross"] = line["unit_price"] * line["quantity"]
line["gross_margin"] = line["gross"] * line["margin_pct"]
ord_val = line.groupby("order_id").agg(gross=("gross","sum"), gm=("gross_margin","sum"), units=("quantity","sum")).reset_index()
orders = orders.merge(ord_val, on="order_id", how="left")
orders["revenue"] = orders["gross"] * (1 - orders["discount_pct"])
orders["profit"] = orders["gm"] - orders["gross"] * orders["discount_pct"]   # discount comes out of margin
orders["month"] = orders["order_date"].dt.to_period("M").dt.to_timestamp()
valid = orders[orders["status"] == "Delivered"].copy()          # revenue-recognised orders
log["dq"]["rows_clean"] = {"customers": len(cust), "orders": len(orders), "delivered_orders": len(valid)}

# persist clean data + SQLite DB for the SQL layer
cust.to_csv(PROC/"customers_clean.csv", index=False); orders.to_csv(PROC/"orders_clean.csv", index=False)
db = sqlite3.connect(PROC/"retail.db")
cust.assign(signup_date=cust.signup_date.dt.strftime("%Y-%m-%d")).to_sql("customers", db, if_exists="replace", index=False)
orders.assign(order_date=orders.order_date.dt.strftime("%Y-%m-%d"), month=orders.month.dt.strftime("%Y-%m")).to_sql("orders", db, if_exists="replace", index=False)
items.to_sql("order_items", db, if_exists="replace", index=False); prod.to_sql("products", db, if_exists="replace", index=False)

# run every SQL query in sql/queries.sql and save as tables (proves SQL skills end-to-end)
sql_text = (ROOT/"sql/queries.sql").read_text()
for block in sql_text.split("-- name:")[1:]:
    name, q = block.split("\n", 1)
    pd.read_sql(q.strip().rstrip(";"), db).to_csv(TB/f"sql_{name.strip()}.csv", index=False)
db.close()

# ============ 2. REVENUE TREND & SEASONALITY ============
m = valid.groupby("month").agg(revenue=("revenue","sum"), orders=("order_id","nunique"), profit=("profit","sum")).reset_index()
m["mom_growth_%"] = m["revenue"].pct_change() * 100
m.to_csv(TB/"monthly_revenue.csv", index=False)
fig, ax = plt.subplots(figsize=(12, 5.5))
ax.fill_between(m["month"], m["revenue"]/1e5, alpha=.18); ax.plot(m["month"], m["revenue"]/1e5, marker="o", lw=2.5)
for mm in m[m["month"].dt.month.isin([10, 11])]["month"]: ax.axvspan(mm - pd.Timedelta(days=15), mm + pd.Timedelta(days=15), color="orange", alpha=.2)
ax.set_title("Monthly Revenue (₹ Lakh) — festive season highlighted"); ax.set_ylabel("₹ Lakh"); ax.set_xlabel("")
fig.tight_layout(); fig.savefig(CH/"01_monthly_revenue.png"); plt.close()

festive = valid[valid.month.dt.month.isin([10, 11])]; rest = valid[~valid.month.dt.month.isin([10, 11])]
log["festive_share_of_revenue_%"] = round(festive.revenue.sum() / valid.revenue.sum() * 100, 1)
log["festive_months_share_of_calendar_%"] = round(2 / 12 * 100, 1)
log["total_revenue"] = float(valid.revenue.sum()); log["total_profit"] = float(valid.profit.sum())
log["aov"] = float(valid.revenue.mean())

# ============ 3. CATEGORY PROFITABILITY ============
dl = line.merge(valid[["order_id", "discount_pct"]], on="order_id")
dl["revenue"] = dl["gross"] * (1 - dl["discount_pct"]); dl["profit"] = dl["gross_margin"] - dl["gross"] * dl["discount_pct"]
cat = dl.groupby("category").agg(revenue=("revenue","sum"), profit=("profit","sum")).reset_index()
cat["profit_margin_%"] = cat.profit / cat.revenue * 100; cat = cat.sort_values("revenue", ascending=False)
cat.to_csv(TB/"category_profitability.csv", index=False)
fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
sns.barplot(data=cat, y="category", x=cat.revenue/1e5, ax=axes[0], color="#4C72B0"); axes[0].set_title("Revenue by Category (₹ Lakh)"); axes[0].set_xlabel(""); axes[0].set_ylabel("")
sns.barplot(data=cat.sort_values("profit_margin_%"), y="category", x="profit_margin_%", ax=axes[1], color="#55A868"); axes[1].set_title("Profit Margin % after discounts"); axes[1].set_xlabel(""); axes[1].set_ylabel("")
fig.tight_layout(); fig.savefig(CH/"02_category_profitability.png"); plt.close()
log["top_cat_by_revenue"] = cat.iloc[0].category; log["top_cat_rev_share_%"] = round(cat.iloc[0].revenue/cat.revenue.sum()*100, 1)
log["best_margin_cat"] = cat.sort_values("profit_margin_%").iloc[-1].category; log["worst_margin_cat"] = cat.sort_values("profit_margin_%").iloc[0].category
log["margins"] = cat.set_index("category")["profit_margin_%"].round(1).to_dict()

# ============ 4. COHORT RETENTION ============
o = valid.merge(cust[["customer_id", "signup_date", "acquisition_channel"]], on="customer_id")
o["cohort"] = o["signup_date"].dt.to_period("M"); o["period"] = (o["order_date"].dt.to_period("M") - o["cohort"]).apply(lambda x: x.n)
co = o[o.period >= 0].groupby(["cohort", "period"])["customer_id"].nunique().unstack(fill_value=0)
size = cust.groupby(cust.signup_date.dt.to_period("M")).size().reindex(co.index)
ret = co.div(size, axis=0) * 100
ret = ret[ret.index <= pd.Period("2025-06")].iloc[:, :9]        # cohorts with >=6 months of history
last_m = valid.order_date.max().to_period("M")
for c_ in ret.index:                                           # mask not-yet-observed months (right-censoring)
    for p_ in ret.columns:
        if c_ + p_ > last_m: ret.loc[c_, p_] = np.nan
ret.index = ret.index.astype(str)
fig, ax = plt.subplots(figsize=(13, 8))
sns.heatmap(ret, annot=True, fmt=".0f", mask=ret.isna(), cmap="YlGnBu", cbar_kws={"label": "% of cohort active"}, ax=ax, annot_kws={"size": 9})
ax.set_title("Monthly Cohort Retention (% of signups who ordered in month N)"); ax.set_xlabel("Months since signup"); ax.set_ylabel("Signup cohort")
fig.tight_layout(); fig.savefig(CH/"03_cohort_retention.png"); plt.close(); ret.to_csv(TB/"cohort_retention.csv")

# ============ 5. CHANNEL QUALITY (repeat rate, LTV) + STAT TEST ============
cs = valid.groupby("customer_id").agg(orders=("order_id","nunique"), revenue=("revenue","sum"), profit=("profit","sum"),
                                       first=("order_date","min"), last=("order_date","max")).reset_index()
base = cust.merge(cs, on="customer_id", how="left").fillna({"orders": 0, "revenue": 0, "profit": 0})
base["repeat"] = base["orders"] >= 2
ch = base[base.acquisition_channel != "Unknown"].groupby("acquisition_channel").agg(
    customers=("customer_id","count"), repeat_rate=("repeat","mean"), avg_orders=("orders","mean"),
    ltv=("revenue","mean"), profit_per_cust=("profit","mean")).reset_index()
ch["repeat_rate"] *= 100; ch = ch.sort_values("ltv", ascending=False); ch.to_csv(TB/"channel_quality.csv", index=False)
fig, axes = plt.subplots(1, 2, figsize=(14, 5.5))
sns.barplot(data=ch, y="acquisition_channel", x="repeat_rate", ax=axes[0], color="#C44E52"); axes[0].set_title("Repeat-purchase rate %"); axes[0].set_ylabel(""); axes[0].set_xlabel("")
sns.barplot(data=ch, y="acquisition_channel", x="ltv", ax=axes[1], color="#8172B2"); axes[1].set_title("Avg customer lifetime value (₹)"); axes[1].set_ylabel(""); axes[1].set_xlabel("")
fig.tight_layout(); fig.savefig(CH/"04_channel_quality.png"); plt.close()
ct = pd.crosstab(base[base.acquisition_channel != "Unknown"].acquisition_channel, base[base.acquisition_channel != "Unknown"].repeat)
chi2, pval, *_ = stats.chi2_contingency(ct)
log["chi2_channel_vs_repeat_p"] = float(pval)
a, b = (base[base.acquisition_channel == c].revenue for c in ("Referral", "Paid Social"))
log["mannwhitney_referral_vs_paidsocial_p"] = float(stats.mannwhitneyu(a, b).pvalue)
log["channel"] = ch.set_index("acquisition_channel")[["repeat_rate", "ltv", "customers"]].round(1).to_dict("index")

# ============ 6. PARETO / CUSTOMER CONCENTRATION ============
s = base.sort_values("revenue", ascending=False).reset_index(drop=True); s["cum_cust_%"] = (s.index + 1) / len(s) * 100
s["cum_rev_%"] = s.revenue.cumsum() / s.revenue.sum() * 100
log["top10pct_customers_rev_share_%"] = round(float(s.loc[s["cum_cust_%"] <= 10, "revenue"].sum() / s.revenue.sum() * 100), 1)
log["top20pct_customers_rev_share_%"] = round(float(s.loc[s["cum_cust_%"] <= 20, "revenue"].sum() / s.revenue.sum() * 100), 1)
fig, ax = plt.subplots(figsize=(9, 6)); ax.plot(s["cum_cust_%"], s["cum_rev_%"], lw=3); ax.plot([0, 100], [0, 100], "--", c="grey")
ax.axvline(20, c="red", ls=":"); ax.set_title("Revenue Concentration (Lorenz/Pareto)"); ax.set_xlabel("% of customers (best first)"); ax.set_ylabel("% of revenue")
fig.tight_layout(); fig.savefig(CH/"05_pareto.png"); plt.close()

# ============ 7. RFM SEGMENTATION ============
snap = valid.order_date.max() + pd.Timedelta(days=1)
rfm = cs.assign(recency=(snap - cs["last"]).dt.days, frequency=cs["orders"], monetary=cs["revenue"])[["customer_id", "recency", "frequency", "monetary"]]
rfm["R"] = pd.qcut(rfm.recency, 5, labels=[5, 4, 3, 2, 1]).astype(int)
rfm["F"] = pd.qcut(rfm.frequency.rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
rfm["M"] = pd.qcut(rfm.monetary.rank(method="first"), 5, labels=[1, 2, 3, 4, 5]).astype(int)
def seg(r):
    if r.R >= 4 and r.F >= 4: return "Champions"
    if r.F >= 4: return "Loyal"
    if r.R >= 4 and r.F <= 2: return "New / Promising"
    if r.R <= 2 and r.F >= 3: return "At Risk (high value)"
    if r.R <= 2: return "Hibernating"
    return "Needs Attention"
rfm["segment"] = rfm.apply(seg, axis=1); rfm.to_csv(TB/"rfm_customers.csv", index=False)
sg = rfm.groupby("segment").agg(customers=("customer_id","count"), revenue=("monetary","sum"), avg_recency=("recency","mean")).reset_index()
sg["rev_share_%"] = sg.revenue / sg.revenue.sum() * 100; sg["cust_share_%"] = sg.customers / sg.customers.sum() * 100
sg = sg.sort_values("revenue", ascending=False); sg.to_csv(TB/"rfm_segments.csv", index=False)
fig, ax = plt.subplots(figsize=(11, 5.5)); x = np.arange(len(sg)); w = .38
ax.bar(x - w/2, sg["cust_share_%"], w, label="% of customers"); ax.bar(x + w/2, sg["rev_share_%"], w, label="% of revenue")
ax.set_xticks(x); ax.set_xticklabels(sg.segment, rotation=20, ha="right"); ax.legend(); ax.set_title("RFM Segments: customer share vs revenue share")
fig.tight_layout(); fig.savefig(CH/"06_rfm_segments.png"); plt.close()
log["rfm"] = sg.set_index("segment")[["customers", "rev_share_%", "cust_share_%"]].round(1).to_dict("index")
rec_at_risk = rfm[rfm.segment == "At Risk (high value)"]; log["at_risk_revenue_at_stake"] = float(rec_at_risk.monetary.sum())

# ============ 8. DISCOUNT IMPACT ============
d = orders[orders.status.isin(["Delivered", "Returned"])].copy(); d["band"] = pd.cut(d.discount_pct, [-.01, 0, .05, .10, .25], labels=["0%", "5%", "10%", "20%"])
dd = d.groupby("band", observed=True).agg(orders=("order_id","count"), aov=("revenue","mean"), return_rate=("status", lambda x: (x == "Returned").mean()*100), profit_per_order=("profit","mean")).reset_index()
dd.to_csv(TB/"discount_impact.csv", index=False)
fig, axes = plt.subplots(1, 2, figsize=(13, 5)); sns.barplot(data=dd, x="band", y="aov", ax=axes[0], color="#64B5CD"); axes[0].set_title("AOV by discount (₹)"); axes[0].set_xlabel("")
sns.barplot(data=dd, x="band", y="profit_per_order", ax=axes[1], color="#CCB974"); axes[1].set_title("Profit per order by discount (₹)"); axes[1].set_xlabel("")
fig.tight_layout(); fig.savefig(CH/"07_discount_impact.png"); plt.close()
log["discount_profit_per_order"] = dd.set_index("band")["profit_per_order"].round(0).to_dict(); log["discount_aov"] = dd.set_index("band")["aov"].round(0).to_dict()

# ============ 9. PREDICT: will a new customer repeat within 90 days? ============
fo = valid.sort_values("order_date").groupby("customer_id").first().reset_index()
sec = valid.sort_values("order_date").groupby("customer_id")["order_date"].apply(lambda x: x.iloc[1] if len(x) > 1 else pd.NaT).rename("second")
ml = cust.merge(fo[["customer_id", "order_date", "revenue", "units", "discount_pct", "payment_method"]], on="customer_id").merge(sec, on="customer_id", how="left")
ml = ml[ml.order_date <= pd.Timestamp("2025-09-30")]                              # need 90d of follow-up
ml["y"] = ((ml.second - ml.order_date).dt.days <= 90).astype(int)
X = pd.get_dummies(ml[["age", "acquisition_channel", "revenue", "units", "discount_pct", "payment_method", "city"]], drop_first=True)
Xtr, Xte, ytr, yte = train_test_split(X, ml.y, test_size=.25, random_state=7, stratify=ml.y)
mu, sd = Xtr.mean(), Xtr.std().replace(0, 1)
clf = LogisticRegression(max_iter=2000).fit((Xtr - mu) / sd, ytr)
log["model_auc"] = round(float(roc_auc_score(yte, clf.predict_proba((Xte - mu) / sd)[:, 1])), 3); log["model_base_rate_%"] = round(float(ml.y.mean() * 100), 1)
co_ = pd.Series(clf.coef_[0], index=X.columns).sort_values(); top = pd.concat([co_.head(5), co_.tail(5)])
fig, ax = plt.subplots(figsize=(10, 6)); ax.barh(top.index, top.values, color=np.where(top.values > 0, "#55A868", "#C44E52"))
ax.set_title("What predicts a 90-day repeat purchase? (standardised logistic coefficients)"); fig.tight_layout(); fig.savefig(CH/"08_repeat_drivers.png"); plt.close()
log["top_positive_drivers"] = list(co_.tail(3).index[::-1]); log["top_negative_drivers"] = list(co_.head(3).index)

json.dump(log, open(TB/"key_metrics.json", "w"), indent=2, default=str)
print(json.dumps(log, indent=2, default=str))
