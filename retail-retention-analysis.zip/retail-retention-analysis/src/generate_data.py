"""Generate a realistic, deliberately messy synthetic e-commerce dataset (INR).
Seeded so results are reproducible. Messiness (dupes, nulls, casing, invalid dates)
is injected on purpose so the cleaning step in the analysis is meaningful."""
import numpy as np, pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
OUT = Path(__file__).resolve().parents[1] / "data" / "raw"
OUT.mkdir(parents=True, exist_ok=True)

N_CUST = 6000
START, END = pd.Timestamp("2024-01-01"), pd.Timestamp("2025-12-31")

cities = {"Mumbai":.16,"Delhi":.15,"Bengaluru":.14,"Hyderabad":.09,"Chennai":.08,"Pune":.08,
          "Kolkata":.07,"Ahmedabad":.05,"Bhubaneswar":.04,"Jaipur":.04,"Lucknow":.04,"Kochi":.03,"Berhampur":.03}
channels = {"Organic Search":.30,"Paid Social":.25,"Email":.12,"Referral":.13,"Direct":.12,"Influencer":.08}
signup = START + pd.to_timedelta(rng.beta(1.15, 1.25, N_CUST) * (END - START).days * 0.97, unit="D")
cust = pd.DataFrame({
    "customer_id": np.arange(1, N_CUST + 1),
    "signup_date": signup.normalize(),
    "city": rng.choice(list(cities), N_CUST, p=np.array(list(cities.values())) / sum(cities.values())),
    "acquisition_channel": rng.choice(list(channels), N_CUST, p=list(channels.values())),
    "age": np.clip(rng.normal(31, 8, N_CUST), 18, 65).round().astype(int),
    "gender": rng.choice(["F", "M", "Other"], N_CUST, p=[.48, .49, .03]),
})

cats = {"Electronics":(2500,25000,.22),"Fashion":(400,4500,.45),"Home & Kitchen":(300,7000,.35),
        "Beauty":(200,2500,.50),"Books":(150,900,.30),"Sports":(500,8000,.33)}
prod, pid = [], 1
for c, (lo, hi, margin) in cats.items():
    for _ in range(10):
        price = round(float(np.exp(rng.uniform(np.log(lo), np.log(hi)))), -1)
        prod.append((pid, f"{c[:4].upper()}-{pid:03d}", c, price, round(margin + rng.normal(0, .04), 3)))
        pid += 1
prod = pd.DataFrame(prod, columns=["product_id", "product_name", "category", "unit_price", "margin_pct"])

# Hidden story: acquisition channel quality drives repeat-purchase behaviour
quality = {"Organic Search":1.0,"Paid Social":0.55,"Email":1.25,"Referral":1.45,"Direct":1.1,"Influencer":0.7}
season = {1:.9,2:.85,3:.95,4:.9,5:.95,6:.9,7:.95,8:1.0,9:1.05,10:1.5,11:1.6,12:1.2}  # festive spike

orders, items, oid = [], [], 1
for r in cust.itertuples():
    q = quality[r.acquisition_channel]
    n_orders = 1 + rng.poisson(1.1 * q * (1.2 if r.age < 35 else .9))
    if rng.random() < 0.08 * q:
        n_orders += rng.integers(6, 14)
    t = r.signup_date
    for k in range(n_orders):
        gap = rng.gamma(2.0, 28 / q) if k else rng.exponential(3)
        t = t + pd.Timedelta(days=float(gap))
        if t > END: break
        if rng.random() > season[t.month] / 1.6 and rng.random() < .5:
            continue
        pids = rng.choice(prod.product_id, 1 + rng.poisson(.7), replace=False)
        disc = rng.choice([0, .05, .10, .20], p=[.55, .15, .2, .1]) if t.month in (10, 11) \
            else rng.choice([0, .05, .10], p=[.75, .15, .1])
        for p in pids:
            items.append((oid, int(p), int(1 + rng.poisson(.25))))
        status = rng.choice(["Delivered", "Returned", "Cancelled"], p=[.88, .07, .05])
        orders.append((oid, r.customer_id, t.normalize(), disc,
                       rng.choice(["UPI","Card","COD","NetBanking"], p=[.46,.22,.24,.08]), status))
        oid += 1

orders = pd.DataFrame(orders, columns=["order_id","customer_id","order_date","discount_pct","payment_method","status"])
items = pd.DataFrame(items, columns=["order_id","product_id","quantity"])

# ---- inject mess ----
cust.loc[rng.choice(N_CUST, 180, replace=False), "age"] = np.nan
cust.loc[rng.choice(N_CUST, 60, replace=False), "age"] = rng.choice([0, 150, 999], 60)
idx = rng.choice(N_CUST, 250, replace=False); cust.loc[idx, "city"] = cust.loc[idx, "city"].str.upper()
idx = rng.choice(N_CUST, 120, replace=False); cust.loc[idx, "city"] = " " + cust.loc[idx, "city"].str.lower() + " "
cust.loc[rng.choice(N_CUST, 90, replace=False), "acquisition_channel"] = np.nan
orders = pd.concat([orders, orders.sample(140, random_state=1)], ignore_index=True)
orders.loc[orders.sample(70, random_state=2).index, "payment_method"] = None
orders["order_date"] = pd.to_datetime(orders["order_date"]).dt.strftime("%Y-%m-%d")
orders.loc[orders.sample(35, random_state=3).index, "order_date"] = "2026-13-45"
cust["signup_date"] = cust["signup_date"].dt.strftime("%Y-%m-%d")

cust.to_csv(OUT/"customers.csv", index=False)
prod.to_csv(OUT/"products.csv", index=False)
orders.to_csv(OUT/"orders.csv", index=False)
items.to_csv(OUT/"order_items.csv", index=False)
print(f"customers={len(cust):,} products={len(prod)} orders={len(orders):,} items={len(items):,}")
